import android.app.Application
import android.content.Context

class App : Application() {
    companion object {
        private var context: Context? = null

        fun getContext(): Context {
            return context ?: throw IllegalStateException("Context is not initialized")
        }
    }

    override fun onCreate() {
        super.onCreate()
        context = applicationContext
    }
}
