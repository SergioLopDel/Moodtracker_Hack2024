package com.example.moodtracker

import ApiService
import StringResponse
import android.os.Bundle
import android.widget.Toast

import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldColors
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Color.Companion.Red
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.moodtracker.ui.theme.MoodTrackerTheme
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MoodTrackerTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ){
                    GreetingWork(
                        modifier = Modifier
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GreetingWork(modifier: Modifier=Modifier){
    val imagen = painterResource(id = R.drawable.pexels_sean_whang_25006_804269)
    val logo = painterResource(id = R.drawable.logitosinfondo)

    var text1 by remember { mutableStateOf(TextFieldValue("")) }
    var text2 by remember { mutableStateOf(TextFieldValue("")) }

    var isLoggedIn by remember { mutableStateOf(false) }


    Box{
        Image(
            painter = imagen,
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            //modifier = modifier.height(270.dp)
        )
    }
    Column(
        verticalArrangement = Arrangement.Center,//spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.fillMaxSize().padding(10.dp),
    ){
        Image(
        painter = logo,
        contentDescription = null,
        contentScale = ContentScale.Fit,
        modifier = modifier.height(130.dp)
        )
    if(!isLoggedIn) {
        Text(
            text = "Welcome to Moodtracker",
            Modifier.padding(14.dp),
            lineHeight = 50.sp,
            textAlign = TextAlign.Center,
            fontSize = 45.sp
        )

        OutlinedTextField(
            value = text1,
            label = { Text(text = "Enter Your mail") },
            onValueChange = {
                text1 = it
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedLabelColor = Color.Black,
                unfocusedLabelColor = Color.Black
            ),
        )

        Text(
            text = "",
            Modifier.padding(2.dp),
            lineHeight = 50.sp,
            textAlign = TextAlign.Center,
            fontSize = 45.sp
        )

        OutlinedTextField(
            value = text2,
            label = { Text(text = "Enter Your password") },
            onValueChange = {
                text2 = it
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedLabelColor = Color.Black,
                unfocusedLabelColor = Color.Black
            ),
        )
        Text(
            text = "",
            Modifier.padding(2.dp),
            lineHeight = 50.sp,
            textAlign = TextAlign.Center,
            fontSize = 45.sp
        )
        Button(
            onClick = { isLoggedIn =true},
            colors = ButtonDefaults.buttonColors(Color.Cyan)
        )
        {
            Text(text = "Log in")
        }
    }else{
        Text(
            text = "Worker Report",
            Modifier.padding(2.dp),
            lineHeight = 50.sp,
            textAlign = TextAlign.Center,
            fontSize = 45.sp
        )
        Text(
            text = "If you're feeling fearful during work hours, here are two actions you can take to help manage your emotions:\n" +
                    "\n" +
                    "First, take a few minutes to step away from your workspace and take some deep breaths. Find a quiet spot where you can sit comfortably and focus on your breathing. Inhale slowly through your nose, hold your breath for a few seconds, and then exhale slowly through your mouth. This simple act can help calm your nervous system and reduce feelings of anxiety.\n" +
                    "\n" +
                    "Second, try to reframe your fearful thoughts by asking yourself a few questions. Ask yourself what is causing your fear, and whether it's based on reality or just your imagination. Ask yourself if there's anything you can do to address the source of your fear, and if there are any positive outcomes that could come from the situation. By challenging your negative thoughts and focusing on the present moment, you can begin to shift your perspective and feel more in control.",
            modifier = Modifier.padding(2.dp),
            lineHeight = 30.sp,
            textAlign = TextAlign.Center,
            fontSize = 15.sp
        )

    }
    }

}


@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MoodTrackerTheme {
        GreetingWork(
            modifier = Modifier.padding(4.dp)
        )
    }
}