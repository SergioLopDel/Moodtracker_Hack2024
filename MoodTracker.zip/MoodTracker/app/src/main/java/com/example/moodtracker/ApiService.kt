import retrofit2.Call
import retrofit2.http.GET

data class StringResponse(val message: String?)

interface ApiService {
    @GET("get-string")
    fun getString(): Call<StringResponse>
}
